# Plano Cartesiano Interativo — Atelier Function

Projeto pronto para GitHub Pages.

Ajuste desta versão:
- Melhoramento do eixo X do gráfico.
- Rótulos do eixo X agora usam espaçamento inteligente conforme o zoom e o deslocamento do plano.
- Remoção do travamento/clamp lateral que causava números acumulados ou com aparência bugada nas bordas.
- Manutenção do comportamento de apagar ponto selecionado por duplo clique, conforme solicitado.

Demais recursos preservados: criar pontos, traçar reta, análise matemática, exportar PDF, exportar/importar projeto e apagar todos os pontos.
